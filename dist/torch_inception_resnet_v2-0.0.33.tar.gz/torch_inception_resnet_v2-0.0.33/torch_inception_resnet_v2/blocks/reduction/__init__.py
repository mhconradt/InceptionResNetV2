from .reduction_block import ReductionBlock
from .a import ReductionA
from .b import ReductionB
