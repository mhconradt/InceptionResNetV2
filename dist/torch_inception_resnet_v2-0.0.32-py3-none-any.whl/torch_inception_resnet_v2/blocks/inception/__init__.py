from .a import InceptionA
from .b import InceptionB
from .c import InceptionC
